(function() {
  "use strict";

  ready(function() {

    // Restore focus after page reload
    var returnFocusTo = sessionStorage.getItem('returnFocusTo');
    if (returnFocusTo) {
      sessionStorage.removeItem('returnFocusTo');
      var returnFocusToEl = document.querySelector(returnFocusTo);
      returnFocusToEl && returnFocusToEl.focus && returnFocusToEl.focus();
    }

    // Render inline micro-templates
    each('[data-element="template"]', function(el) {
      if (el.hasAttribute('data-template')) {
        Util.renderTemplate(el, el.getAttribute('data-template'));
      }
    });

    /**
     * Converts HTML links within a given element into objects.
     * @param el
     * @returns {[]}
     */
    var convertLinksToObjects = function(el) {
      return Array.prototype.map.call(el.querySelectorAll('a'), function(a) {
        return { title: a.innerText, html_url: a.href };
      });
    };

    // Render Zendesk helper micro-templates
    // @see https://developer.zendesk.com/documentation/help_center/help-center-templates/helpers/
    var supportedHelpers = ['breadcrumbs', 'recent-articles', 'related-articles', 'recent-activity', 'share'];
    supportedHelpers.forEach(function(helper) {
      each('[data-element="' + helper + '"]', function(el) {
        if (el.hasAttribute('data-template')) {
          var data = {};

          // Breadcrumb helper data
          if (helper === 'breadcrumbs') {
            data = { breadcrumbs: convertLinksToObjects(el) };
          }

          // Recent and related articles helper data
          else if (helper === 'recent-articles' || helper === 'related-articles') {
            data = { articles: convertLinksToObjects(el) };
          }

          // Recent activity helper data
          else if (helper === 'recent-activity') {
            data = { items: convertLinksToObjects(el) };
          }

          // Social share links helper data
          else if (helper === 'share') {
            var links = Array.prototype.map.call(el.querySelectorAll('a'), function(a) {
              var svg = a.querySelector('svg');
              return {
                title: a.getAttribute('aria-label'),
                description: svg ? svg.getAttribute('aria-label') : '',
                html_url: a.href
              };
            });
            data = { links: links };
          }

          // Render the micro-template
          Util.renderTemplate(el, el.getAttribute('data-template'), data);
        }
      });
    });

    // Open social sharing links in a new window
    each('.share a', function(a) {
      a.addEventListener('click', function(e) {
        e.preventDefault();
        window.open(this.href, '', 'height = 500, width = 500');
      });
    });

    // Add focus classname to search field
    each('.form-field [type="search"]', function(el) {
      el.addEventListener('focus', function() { this.parentNode.classList.add(Util.classNames.FOCUS); });
      el.addEventListener('focusout', function() { this.parentNode.classList.remove(Util.classNames.FOCUS); });
    });

    // Replace images with inline SVG
    Array.prototype.forEach.call(document.querySelectorAll('[data-inline-svg]'), Util.replaceWithSVG);

    // Smooth scroll
    function maybeScroll() {
      var smoothScroll = Util.getURLParameter('smooth-scroll', window.location);
      if (smoothScroll === 'true' && window.location.hash) {
        var offset = Util.getURLParameter('offset', window.location);
        var target = document.getElementById(window.location.hash.substring(1).split("?")[0]);
        Util.scrollIntoView(target, offset);
      }
    }

    window.addEventListener('hashchange', maybeScroll, false);
    maybeScroll();

    /**
     * Collapsible navigation.
     * @param el
     * @constructor
     */
    function CollapsibleNav(el) {
      this.el = el;
      el.addEventListener('click', this.onClick.bind(this));
    }

    CollapsibleNav.prototype = {

      onClick: function(e) {
        var maxHeight = window.getComputedStyle(this.el).maxHeight;
        if (maxHeight === 'none') {
          return;
        }

        var isExpanded = this.el.getAttribute('aria-expanded') === 'true';
        var navLink = e.target;

        if (isExpanded) {

          // Close the nav if the clicked link is selected
          if (navLink.getAttribute('aria-selected') === 'true') {
            this.el.setAttribute('aria-expanded', 'false');
            this.el.classList.remove('is-expanded');
            navLink.setAttribute('aria-selected', 'false');
            e.preventDefault();
          }
        } else {

          // Open the nav if it's closed
          this.el.setAttribute('aria-expanded', 'true');
          this.el.classList.add('is-expanded');
          navLink.setAttribute('aria-selected', 'true');
          e.preventDefault();
        }
      }
    };

    each('.collapsible-nav', function(nav) {
      new CollapsibleNav(nav);
    });

    window.CollapsibleNav = CollapsibleNav;

  });
})();

/**
 * Expose a stable, frontend-friendly view of the authenticated Help Center
 * user. Zendesk provides HelpCenter.user, but custom code should not need to
 * know which fields are optional or calculate the email domain itself.
 *
 * This augments the native HelpCenter object; it does not replace it.
 */
function initializeHelpCenterUserContext() {
  var helpCenter = window.HelpCenter || (window.HelpCenter = {});
  var user = helpCenter.user || null;

  // Anonymous visitors are treated as cardholders. Zendesk may not expose a
  // user object until authentication has completed, so keep the context
  // available in both states.
  if (!user) {
    helpCenter.userContext = {
      authenticated: false,
      user: null,
      email: null,
      emailDomain: null,
      userType: 'cardholder',
      organizations: [],
      organization: null,
      organisation: null
    };

    console.log('[SBSA] Resolved user role:', helpCenter.userContext.userType);

    return helpCenter.userContext;
  }

  console.log('[SBSA] Zendesk HelpCenter.user object:', user);

  var organizations = Array.isArray(user.organizations) ? user.organizations : [];
  var email = typeof user.email === 'string' ? user.email.trim() : '';
  var emailAt = email.lastIndexOf('@');
  var emailDomain = emailAt > -1 ? email.slice(emailAt + 1).toLowerCase() : null;
  var organization = organizations.length ? organizations[0] : null;
  var bankerDomain = 'standardbank.co.za';
  var paymentologyDomain = 'paymentology.com';
  var paycardProfileAdminFieldId = '30580594462364';
  var userTags = Array.isArray(user.tags) ? user.tags : [];
  var userFields = user.user_fields || {};
  var paycardProfileAdminValue = userFields[paycardProfileAdminFieldId];
  var normalizedPaycardProfileAdminValue = typeof paycardProfileAdminValue === 'string'
    ? paycardProfileAdminValue.trim().toLowerCase()
    : '';
  var isPaycardProfileAdmin = userTags.indexOf('sbsa_paycard_profile_admin') !== -1 ||
    normalizedPaycardProfileAdminValue === 'sbsa_paycard_profile_admin' ||
    normalizedPaycardProfileAdminValue === 'paycard profile admin';
  var isPaymentologyUser = emailDomain === paymentologyDomain ||
    (emailDomain && emailDomain.slice(-(paymentologyDomain.length + 1)) === '.' + paymentologyDomain);
  var userType = isPaymentologyUser
    ? 'paymentology-user'
    : emailDomain === bankerDomain
      ? 'banker'
      : isPaycardProfileAdmin
        ? 'paycard-profile-admin'
        : 'cardholder';

  helpCenter.userContext = {
    authenticated: true,
    user: user,
    email: email || null,
    emailDomain: emailDomain,
    userType: userType,
    isPaymentologyUser: isPaymentologyUser,
    isPaycardProfileAdmin: isPaycardProfileAdmin,
    organizations: organizations,
    organization: organization,
    // Keep the UK spelling available for existing Paymentology terminology.
    organisation: organization
  };

  console.log('[SBSA] Resolved user role:', userType, {
    email: email || null,
    emailDomain: emailDomain,
    userTags: userTags,
    paycardProfileAdminField: paycardProfileAdminValue
  });

  return helpCenter.userContext;
}

var formAudience = {
  '29260608576540': 'banker',
  '29261654683420': 'banker',
  '29261611789980': 'paycard-profile-admin',
  '29261634705564': 'paycard-profile-admin',
  '29261671178908': 'paycard-profile-admin',
  '29284840937372': 'paycard-profile-admin',
  '31419325012892': 'paycard-profile-admin',
  '31419427521564': ['banker', 'paycard-profile-admin']
};

function getTicketFormIdFromURL(url) {
  var match = String(url || '').match(/[?&]ticket_form_id=(\d+)/);
  return match ? match[1] : null;
}

function isTicketFormAllowed(formId, userType) {
  // Paymentology staff can access every form without a separately assigned role.
  if (userType === 'paymentology-user') return true;
  var audience = formAudience[formId];
  if (!audience) return true;
  if (Array.isArray(audience)) {
    return audience.indexOf(userType) !== -1;
  }
  return audience === userType;
}

function enforceFormAudience() {
  var userType = window.HelpCenter && window.HelpCenter.userContext
    ? window.HelpCenter.userContext.userType
    : 'cardholder';
  var currentFormId = getTicketFormIdFromURL(window.location.href);

  // Prevent access when an unauthorized user opens a form URL directly.
  if (currentFormId && !isTicketFormAllowed(currentFormId, userType)) {
    var localeHome = window.location.pathname.match(/^\/hc\/[^/]+/);
    window.location.replace((localeHome ? localeHome[0] : '/hc') + '/');
    return;
  }

  // Remove unauthorized forms from the custom submit-request chooser and
  // Zendesk's native form list when either is rendered on the page.
  Array.prototype.forEach.call(
    document.querySelectorAll('a[href*="ticket_form_id="]'),
    function(link) {
      var formId = getTicketFormIdFromURL(link.href);
      if (formId && !isTicketFormAllowed(formId, userType)) {
        var item = link.closest('li') || link;
        item.style.display = 'none';
        item.setAttribute('aria-hidden', 'true');
      }
    }
  );

  if (userType === 'cardholder') {
    document.documentElement.classList.add('anonymous-user');
    if ((document.documentElement.classList.contains('home-page') || /^\/hc(?:\/[^/]+)?\/?$/.test(window.location.pathname)) && document.body) {
      document.body.style.setProperty('flex', 'none', 'important');
    }
    // These links can be configured as custom header links, so they cannot be
    // controlled only by the built-in signed_in template condition.
    Array.prototype.forEach.call(
      document.querySelectorAll('a[href*="/p/submit_request"], a[href$="/requests"], a[href*="/requests?"]'),
      function(link) {
        var item = link.closest('.nav-link') || link;
        item.style.display = 'none';
        item.setAttribute('aria-hidden', 'true');
      }
    );

    // Keep the home-page support panel visible to anonymous visitors.
    if (document.documentElement.classList.contains('page-home')) {
      var contactBlocks = document.getElementById('contact-blocks');
      if (contactBlocks) {
        contactBlocks.setAttribute('inert', '');
      }

      // Keep the remaining home cards at their normal readable width after
      // unauthorized request cards have been removed.
      var customBlocks = document.getElementById('custom-blocks');
      var customBlockList = customBlocks && customBlocks.querySelector('ul.row');
      if (customBlockList) {
        customBlockList.style.display = 'flex';
        customBlockList.style.flexWrap = 'wrap';
      }

      var footer = document.getElementById('footer');
      if (footer) {
        footer.style.marginTop = '0';
      }
      var homeHero = document.querySelector('.hero#page-container');
      if (homeHero) {
        homeHero.style.marginBottom = '0';
      }
    }
  }
}

function removeZendeskAttribution() {
  var footer = document.getElementById('footer') || document.querySelector('footer');
  if (!footer) {
    return;
  }

  Array.prototype.forEach.call(footer.querySelectorAll('a, span, div, p'), function(element) {
    var text = (element.textContent || '').trim().toLowerCase();
    if (text && /powered by zendesk|theme by zenplates|zendesk support|zenplates/.test(text)) {
      element.remove();
    }
  });
}

function routeContentBlockLinks() {
  var directLinks = {
    'faqs & product information': 'https://paycard-support.zendesk.com/hc/en-us/articles/29188260119452-PayCard-Cardholder-FAQs',
    'cardholder self-service': 'https://paycard-support.zendesk.com/hc/en-us/articles/29390774907292-Self-serve-with-the-PayCard-app'
  };

  Array.prototype.forEach.call(document.querySelectorAll('#content-blocks a'), function(link) {
    var title = (link.textContent || '').trim().toLowerCase();
    if (directLinks[title]) {
      link.href = directLinks[title];
    }
  });
}

function enforceCardholderContentBlocks() {
  var context = window.HelpCenter && window.HelpCenter.userContext;
  if (!context || context.userType !== 'cardholder') return;

  var allowedTitles = {
    'faqs & product information': true,
    'cardholder self-service': true
  };

  Array.prototype.forEach.call(document.querySelectorAll('#content-blocks li'), function(card) {
    var title = (card.querySelector('h2') && card.querySelector('h2').textContent || '')
      .trim()
      .toLowerCase();

    if (title && !allowedTitles[title]) {
      card.style.display = 'none';
    }
  });
}

// Run both immediately and after Zendesk has finished populating page data.
// The immediate call supports scripts loaded after HelpCenter; the ready call
// covers pages where Zendesk injects the authenticated user during bootstrap.
initializeHelpCenterUserContext();
if (typeof ready === 'function') {
  ready(function() {
    initializeHelpCenterUserContext();
    enforceFormAudience();
    enforceCardholderContentBlocks();
    routeContentBlockLinks();
    // Custom content-block templates render asynchronously.
    window.setTimeout(function() {
      enforceCardholderContentBlocks();
      routeContentBlockLinks();
    }, 500);
    removeZendeskAttribution();
    // The native Zendesk form list can be rendered asynchronously.
    window.setTimeout(enforceFormAudience, 500);
    window.setTimeout(removeZendeskAttribution, 500);
  });
}

function runWhenjQueryIsReady(callback, remainingAttempts) {
  var attempts = typeof remainingAttempts === 'number' ? remainingAttempts : 40;

  if (window.jQuery && typeof callback === 'function') {
    callback(window.jQuery);
    return;
  }

  if (attempts <= 0) {
    console.warn('jQuery not available when executing custom Help Center code.');
    return;
  }

  setTimeout(function() {
    runWhenjQueryIsReady(callback, attempts - 1);
  }, 50);
}

/* === CUSTOM CODE === */
var urgency_tag_list = ['urgency_critical'];
var severity_tag_list = ['severity_p1'];
var platform_tag_list = ['platform-field_banking-live_clone', 'platform-field_flexpay_clone', 'platform-field_voucherengine_clone', 'platform-field_unsure_clone']
var product_module_ticket_field_id = '28175955127324';
var product_module_org_field_keys = ['28096102665628', 'product___module__2_'];

runWhenjQueryIsReady(function($) {
  $(function() {
    change_form_label();
    change_labels_per_form();
    
	  var numOrgs = HelpCenter.user.organizations.length;
    var orgTags = []
    
    // Adds Organisation tags to array to validate what Platform options should be removed
    for (var c in HelpCenter.user.organizations) {
      for (var x in HelpCenter.user.organizations[c].tags)
			orgTags.push(HelpCenter.user.organizations[c].tags[x]);
    }
		
    // If the Customer belongs to multiple Organisations, remove the Platform options not relevant to them
    if (numOrgs > 0) {
      removePlatformOptions(orgTags);
    }
    
    // If the Customer is only part of one Organisation, set the Platform field by default
    if (numOrgs == 1) {
    	setPlatformOptions(orgTags);
      setDisputesFields(orgTags);
    }
    
    displayRichHints();
    removeUrgencyTag();
    initProductModuleFieldFilter();
		
    //This code is used to remove the Urgency field for an individual ticket form
    /* 
    var ticketForm = location.search.split('ticket_form_id=')[1];

		if (ticketForm != 8237593396509) {
			removeUrgencyTag();
		}*/
  });
});

function normalizeOrgFieldValues(rawValue) {
  if (!rawValue) {
    return [];
  }

  if (Array.isArray(rawValue)) {
    return rawValue.filter(Boolean);
  }

  if (typeof rawValue === 'string') {
    return rawValue
      .split(',')
      .map(function(value) { return value.trim(); })
      .filter(Boolean);
  }

  return [];
}

function getOrganizationFieldRawValue(org, fieldKeys) {
  if (!org) {
    return null;
  }

  var keys = Array.isArray(fieldKeys) ? fieldKeys : [fieldKeys];
  var containers = [
    org.organization_fields,
    org.fields,
    org.custom_fields
  ];

  for (var c = 0; c < containers.length; c++) {
    var container = containers[c];
    if (!container || typeof container !== 'object') {
      continue;
    }

    for (var k = 0; k < keys.length; k++) {
      var fieldKey = keys[k];
      if (fieldKey in container) {
        return container[fieldKey];
      }
    }
  }

  return null;
}

async function fetchOrganizationDetails(orgId) {
  var response = await fetch('/api/v2/organizations/' + encodeURIComponent(orgId) + '.json');

  if (!response.ok) {
    throw new Error('Unable to fetch organization ' + orgId + ' (status ' + response.status + ')');
  }

  var payload = await response.json();
  return payload.organization || null;
}

async function fetchCurrentUserOrganizations() {
  var response = await fetch('/api/v2/users/me.json?include=organizations');

  if (!response.ok) {
    throw new Error('Unable to fetch current user organizations');
  }

  var payload = await response.json();
  var organizations = Array.isArray(payload.organizations) ? payload.organizations : [];
  return organizations;
}

function filterProductModuleSelectOptions(allowedValues) {
  var fieldElement = document.getElementById('request_custom_fields_' + product_module_ticket_field_id);
  if (!fieldElement) {
    return;
  }

  var normalizedAllowedValues = allowedValues.filter(Boolean);
  var visibleOptionValues = [];
  var select = fieldElement.tagName === 'SELECT'
    ? fieldElement
    : fieldElement.querySelector && fieldElement.querySelector('select');

  if (!select || !select.options) {
    var taggerPayload = fieldElement.getAttribute && fieldElement.getAttribute('data-tagger');
    if (!taggerPayload) {
      console.warn(
        '[Product / Module Filter] Ticket field ' + product_module_ticket_field_id +
        ' is not a native select at filter time.',
        fieldElement
      );
      return;
    }

    try {
      if (!fieldElement.getAttribute('data-original-tagger')) {
        fieldElement.setAttribute('data-original-tagger', taggerPayload);
      }

      var taggerOptions = JSON.parse(taggerPayload);
      var filteredTaggerOptions = taggerOptions.filter(function(option) {
        return !option.value || normalizedAllowedValues.indexOf(option.value) !== -1;
      });

      fieldElement.setAttribute('data-tagger', JSON.stringify(filteredTaggerOptions));

      visibleOptionValues = filteredTaggerOptions
        .map(function(option) { return option.value; })
        .filter(Boolean);

      if (fieldElement.value && normalizedAllowedValues.indexOf(fieldElement.value) === -1) {
        fieldElement.value = '';
        if (window.jQuery) {
          window.jQuery(fieldElement).val('').change();
        }

        var trigger = document.querySelector('[aria-labelledby="request_custom_fields_' + product_module_ticket_field_id + '_label"]');
        if (trigger) {
          trigger.textContent = '-';
        }
      }
    } catch (error) {
      console.warn(
        '[Product / Module Filter] Unable to parse data-tagger for ticket field ' + product_module_ticket_field_id,
        error
      );
    }
    return;
  }

  Array.prototype.slice.call(select.options).forEach(function(option) {
    if (!option.value) {
      return;
    }

    option.hidden = normalizedAllowedValues.indexOf(option.value) === -1;
    if (!option.hidden) {
      visibleOptionValues.push(option.value);
    }
  });

  if (select.value && normalizedAllowedValues.indexOf(select.value) === -1) {
    select.value = '';
    if (window.jQuery) {
      window.jQuery(select).val('').change();
    }
  }
}

function filterProductModuleNestyOptions(allowedValues) {
  var normalizedAllowedValues = allowedValues.filter(Boolean);
  var fieldId = 'request_custom_fields_' + product_module_ticket_field_id;
  var fieldElement = document.getElementById(fieldId);

  if (!window.jQuery) {
    return;
  }

  if (!document.getElementById('product-module-panel-guard-style')) {
    var guardStyle = document.createElement('style');
    guardStyle.id = 'product-module-panel-guard-style';
    guardStyle.textContent = 'body.product-module-panel-opening .nesty-panel{visibility:hidden!important;}';
    document.head.appendChild(guardStyle);
  }

  function filterMenuItemsInContainer(container) {
    if (!container) {
      return [];
    }

    var visibleNestyValues = [];
    var debugRows = [];
    var optionValueByLabel = {};
    var allKnownValues = {};
    var sourceTaggerPayload = fieldElement && fieldElement.getAttribute
      ? (fieldElement.getAttribute('data-original-tagger') || fieldElement.getAttribute('data-tagger'))
      : null;

    if (sourceTaggerPayload) {
      try {
        JSON.parse(sourceTaggerPayload).forEach(function(option) {
          if (option && option.value) {
            var trimmedLabel = String(option.label || '').trim();
            optionValueByLabel[trimmedLabel] = option.value;
            allKnownValues[option.value] = true;
            if (trimmedLabel) {
              allKnownValues[trimmedLabel] = true;
            }
          }
        });
      } catch (error) {
        console.warn('[Product / Module Filter] Unable to parse current data-tagger while filtering menu', error);
      }
    }

    window.jQuery(container).find('li').each(function() {
      var optionId = this.id || '';
      var optionLabel = window.jQuery(this).text().trim();
      var dataValue = this.getAttribute('data-value') || '';
      var mappedValue = optionValueByLabel[optionLabel] || dataValue || optionId;
      var isPlaceholder = optionLabel === '-' || mappedValue === '';
      var looksLikeProductModuleOption =
        !!allKnownValues[optionLabel] ||
        !!allKnownValues[mappedValue] ||
        optionId.indexOf('prod_module_') === 0 ||
        dataValue.indexOf('prod_module_') === 0;
      var isAllowed = normalizedAllowedValues.indexOf(mappedValue) !== -1;
      var action = (!looksLikeProductModuleOption || isPlaceholder || isAllowed) ? 'keep' : 'remove';

      if (action === 'keep') {
        visibleNestyValues.push(mappedValue || optionLabel);
        window.jQuery(this).show();
      } else {
        window.jQuery(this).remove();
      }
    });

    return visibleNestyValues.filter(Boolean);
  }

  var fieldContainer = fieldElement ? fieldElement.closest('.form-field') : null;
  var existingPanel = fieldContainer ? fieldContainer.querySelector('.nesty-panel') : null;
  var dropdownTrigger = fieldContainer ? fieldContainer.querySelector('.nesty-input') : null;
  if (existingPanel) {
    filterMenuItemsInContainer(existingPanel);
  }

  if (dropdownTrigger) {
    dropdownTrigger.removeEventListener('mousedown', window.__productModuleDebugMouseDownHandler, true);
    window.__productModuleDebugMouseDownHandler = function() {
      window.__productModulePanelPendingOpen = true;
      document.body.classList.add('product-module-panel-opening');
    };
    dropdownTrigger.addEventListener('mousedown', window.__productModuleDebugMouseDownHandler, true);

    dropdownTrigger.removeEventListener('click', window.__productModuleDebugClickHandler);
    window.__productModuleDebugClickHandler = function() {
      setTimeout(function() {
        var panelFromField = fieldContainer ? fieldContainer.querySelector('.nesty-panel') : null;
        var globalVisiblePanel = Array.prototype.slice.call(document.querySelectorAll('.nesty-panel')).find(function(panel) {
          return panel.offsetParent !== null;
        });
        var panelToInspect = panelFromField || globalVisiblePanel;

        if (panelToInspect) {
          filterMenuItemsInContainer(panelToInspect);
        }
      }, 50);
    };

    dropdownTrigger.addEventListener('click', window.__productModuleDebugClickHandler);
  } else {
    console.warn('[Product / Module Filter] No .nesty-input trigger found for ticket field ' + product_module_ticket_field_id);
  }

  if (!window.__productModulePanelObserver) {
    window.__productModulePanelObserver = new MutationObserver(function() {
      if (!window.__productModulePanelPendingOpen) {
        return;
      }

      var visiblePanel = Array.prototype.slice.call(document.querySelectorAll('.nesty-panel')).find(function(panel) {
        return panel.offsetParent !== null;
      });

      if (!visiblePanel) {
        return;
      }

      window.__productModulePanelPendingOpen = false;
      filterMenuItemsInContainer(visiblePanel);

      requestAnimationFrame(function() {
        document.body.classList.remove('product-module-panel-opening');
      });
    });

    window.__productModulePanelObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class']
    });
  }

  window.jQuery('.nesty-panel').off('DOMNodeInserted.productModuleFilter');
  window.jQuery('.nesty-panel').on('DOMNodeInserted.productModuleFilter', function() {
    filterMenuItemsInContainer(this);
  });
}

function getProductModuleOptionLabel(optionValue) {
  if (!optionValue) {
    return '';
  }

  var fieldElement = document.getElementById('request_custom_fields_' + product_module_ticket_field_id);
  if (!fieldElement) {
    return optionValue;
  }

  var select = fieldElement.tagName === 'SELECT'
    ? fieldElement
    : fieldElement.querySelector && fieldElement.querySelector('select');

  if (select && select.options) {
    var matchingOption = Array.prototype.slice.call(select.options).find(function(option) {
      return option.value === optionValue;
    });

    if (matchingOption) {
      return matchingOption.textContent.trim();
    }
  }

  var taggerPayload = fieldElement.getAttribute && (fieldElement.getAttribute('data-original-tagger') || fieldElement.getAttribute('data-tagger'));
  if (!taggerPayload) {
    return optionValue;
  }

  try {
    var matchingTaggerOption = JSON.parse(taggerPayload).find(function(option) {
      return option && option.value === optionValue;
    });

    if (matchingTaggerOption && matchingTaggerOption.label) {
      return String(matchingTaggerOption.label).trim();
    }
  } catch (error) {
    console.warn('[Product / Module Filter] Unable to parse data-tagger while resolving option label.', error);
  }

  return optionValue;
}

function autofillSingleProductModuleOption(allowedValues) {
  var normalizedAllowedValues = Array.isArray(allowedValues) ? allowedValues.filter(Boolean) : [];
  if (normalizedAllowedValues.length !== 1) {
    return;
  }

  var fieldElement = document.getElementById('request_custom_fields_' + product_module_ticket_field_id);
  if (!fieldElement || fieldElement.value) {
    return;
  }

  var onlyAllowedValue = normalizedAllowedValues[0];
  var visibleLabel = getProductModuleOptionLabel(onlyAllowedValue);

  fieldElement.value = onlyAllowedValue;

  if (window.jQuery) {
    window.jQuery(fieldElement).val(onlyAllowedValue).change();
  } else {
    fieldElement.dispatchEvent(new Event('change', { bubbles: true }));
  }

  var trigger = document.querySelector('[aria-labelledby="request_custom_fields_' + product_module_ticket_field_id + '_label"]');
  if (trigger && visibleLabel) {
    trigger.textContent = visibleLabel;
  }
}

function applyProductModuleFieldFilter(allowedValues) {
  filterProductModuleSelectOptions(allowedValues);
  filterProductModuleNestyOptions(allowedValues);
  autofillSingleProductModuleOption(allowedValues);
}

function getAllProductModuleValuesFromField() {
  var fieldElement = document.getElementById('request_custom_fields_' + product_module_ticket_field_id);
  if (!fieldElement || !fieldElement.getAttribute) {
    console.warn('[Product / Module Filter] Fallback-to-all failed: field element not found.');
    return [];
  }

  var taggerPayload = fieldElement.getAttribute('data-original-tagger') || fieldElement.getAttribute('data-tagger');
  if (!taggerPayload) {
    console.warn('[Product / Module Filter] Fallback-to-all failed: no data-tagger payload found.');
    return [];
  }

  try {
    var allValues = JSON.parse(taggerPayload)
      .map(function(option) { return option && option.value ? option.value : null; })
      .filter(Boolean);
    return allValues;
  } catch (error) {
    console.warn('[Product / Module Filter] Fallback-to-all failed: unable to parse data-tagger.', error);
    return [];
  }
}

function resolveProductModuleAllowedValuesOrFallback(allowedValues) {
  var normalizedValues = Array.isArray(allowedValues) ? allowedValues.filter(Boolean) : [];
  if (normalizedValues.length) {
    return normalizedValues;
  }

  return getAllProductModuleValuesFromField();
}

function getProductModuleValuesFromHelpCenterTags() {
  if (typeof HelpCenter === 'undefined' || !HelpCenter.user || !Array.isArray(HelpCenter.user.organizations)) {
    console.warn('[Product / Module Filter] HelpCenter organizations are not available.');
    return [];
  }

  var matchingTags = [];

  HelpCenter.user.organizations.forEach(function(org) {
    var orgTags = Array.isArray(org.tags) ? org.tags : [];
    var productModuleTags = orgTags.filter(function(tag) {
      return typeof tag === 'string' && tag.indexOf('prod_module_') === 0;
    });

    matchingTags = matchingTags.concat(productModuleTags);
  });

  return Array.from(new Set(matchingTags));
}

async function initProductModuleFieldFilter() {
  var productModuleField = document.getElementById('request_custom_fields_' + product_module_ticket_field_id);
  if (!productModuleField || typeof HelpCenter === 'undefined' || !HelpCenter.user) {
    return;
  }

  var tagValues = getProductModuleValuesFromHelpCenterTags();
  applyProductModuleFieldFilter(resolveProductModuleAllowedValuesOrFallback(tagValues));
}

/* Change text of Form label */
function change_form_label() {
  var titleEl = document.querySelector('.new-req-title');

  if (!titleEl) return;

  var formNamesEl = document.getElementById('ticket-form-names');
  var formOptions = [];
  try {
    formOptions = JSON.parse(formNamesEl ? formNamesEl.textContent : '[]') || [];
  } catch (error) {
    console.warn('Unable to read ticket form names', error);
  }

  var updateTitle = function() {
    var selectedFormId = new URLSearchParams(window.location.search).get('ticket_form_id');
    var selectedForm = formOptions.find(function(option) {
      return String(option.value) === String(selectedFormId);
    });
    var triggerEl = document.querySelector('#new-request-form .nesty-input');
    var selectorText = triggerEl && triggerEl.innerText.trim();
    titleEl.innerText = (selectedForm && selectedForm.name) ||
      (selectorText && selectorText !== '-' ? selectorText : titleEl.dataset.defaultTitle || 'Submit a Request');
  };

  if (!titleEl.dataset.defaultTitle) titleEl.dataset.defaultTitle = titleEl.innerText.trim();
  updateTitle();

  var formRoot = document.getElementById('new-request-form');
  if (formRoot && !formRoot.dataset.titleObserverAttached) {
    formRoot.dataset.titleObserverAttached = 'true';
    new MutationObserver(updateTitle).observe(formRoot, { childList: true, subtree: true, characterData: true });
  }
}

/* Changes the text of the Summary / Description depending on Form */
function change_labels_per_form() {
    const queryString = window.location.search;
    // Changes label on the Request Attachments section
    var label = $('label[for="request-attachments"]').html("Attachments");

    /* New Fraud Rule */
    if (queryString == "?ticket_form_id=11811207026589") {
        var subject_label = $('label[for="request_subject"]').html("Rule Name");
        var desc_label = $('label[for="request_description"]').html("Rule Description");
        var desc_hint = $('#request_description_hint').html("Describe the rule and what it should achieve. Be specific about txn amount limits, number of transactions, MCC's, time window's etc.");
        var set_dynamic_block_placeholder = $('#request_custom_fields_11527404803101').attr('placeholder', '10d 5h 30m 15s');
    }

    /* Fraud Incident */
    else if (queryString == "?ticket_form_id=11811081570845") {
        var org_name = HelpCenter.user.organizations[0].name;
        var today = getDate();

        var desc_label = $('label[for="request_description"]').html("What activity and peculiar patterns have been observed?");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
        var country_label = $('#request_custom_fields_11527830812829_label').html("From which regions are you seeing activity from?");
        var card_list_label = $('#request_custom_fields_11527290152349_label').html("What type of cards are affected?");
        var spend_types_lable = $('#request_custom_fields_11526728423069_label').html("What types of transactions are affected?");
        var set_subject = $('#request_subject').val('Fraud Incident Report - ' + String(today) + ' [' + org_name + ']');
    }

    /* Amend / Delete Fraud Rule */
    else if (queryString == "?ticket_form_id=11811109144989") {
        var org_name = HelpCenter.user.organizations[0].name;
        var today = getDate();

        var set_dynamic_block_placeholder = $('#request_custom_fields_11527404803101').attr('placeholder', '10d 5h 30m 15s');
        var set_time_limit_placeholder = $('#request_custom_fields_12196590792861').attr('placeholder', '10d 5h 30m 15s');
        var desc_label = $('label[for="request_description"]').html("Additional Info");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
        var set_subject = $('#request_subject').val('Fraud Rule Amendment Request - ' + String(today) + ' [' + org_name + ']');
    }

    /* Block a Merchant Fraud Rule */
    else if (queryString == "?ticket_form_id=10054527307292") {
        var org_name = HelpCenter.user.organizations[0].name;
        var today = getDate();

        var desc_label = $('label[for="request_description"]').html("Additional Info");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
        var set_subject = $('#request_subject').val('Block a Merchant Request  - ' + String(today) + ' [' + org_name + ']');
    }

    /* Card Request */
    else if (queryString == "?ticket_form_id=9252769581341") {
        var transaction_date_label = $('#request_custom_fields_10078465821853_label').html("Transaction Date");
        var transaction_amount_label = $('#request_custom_fields_10078458444189_label').html("Transaction Amount");
    }

    /* FICA Cardholder Migration Request */
    else if (queryString == "?ticket_form_id=13775208908444") {
        var desc_label = $('label[for="request_description"]').html("Any other information");
        var set_subject = $('#request_subject').val('FICA Cardholder Migration Request');
    }

    /* Convert Tracking Number > PAN */
    else if (queryString == "?ticket_form_id=15215270503196") {
        var org_name = HelpCenter.user.organizations[0].name;
        var user_name = HelpCenter.user.name;
        var today = getDate();

        var desc_label = $('label[for="request_description"]').html("Additional Info");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
        // var set_desc = $('#request_description_mimetype').val('Request from ' + user_name + ' on behalf of ' + org_name + ' [VoucherEngine] to convert a Tracking Number to PAN.\n' );
        var set_subject = $('#request_subject').val('Convert a Tracking Number to PAN - ' + String(today) + ' [' + org_name + '] [VoucherEngine]' );
        var conversion_list_provision = $('#request_custom_fields_15214816455196_label').html("How would you like to provide the list of Tracking Numbers?");
        var conversion_list = $('#request_custom_fields_15214911706140_label').html("Tracking Numbers to be converted");
    }

    /* Convert Token > PAN */
    else if (queryString == "?ticket_form_id=15215216284572") {
        var org_name = HelpCenter.user.organizations[0].name;
        var user_name = HelpCenter.user.name;
        var today = getDate();

        var desc_label = $('label[for="request_description"]').html("Additional Info");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
        // var set_desc = $('#request_description_mimetype').val('Request from ' + user_name + ' on behalf of ' + org_name + ' [Banking.Live] to convert a Token to PAN.\n' );
        var set_subject = $('#request_subject').val('Convert a Token to PAN - ' + String(today) + ' [' + org_name + '] [Banking.Live]');
    }
  
  	/* MC Fraud Reporting */
    else if (queryString == "?ticket_form_id=16257750048796") {				
        var desc_label = $('label[for="request_description"]').html("Additional Info");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
      	var transaction_date_label = $('#request_custom_fields_10078465821853_label').html("Transaction Date");
				var transaction_date_hint = $('#request_custom_fields_10078465821853_hint').html("The date of the transaction");
      	var tracking_num_hint = $('#request_custom_fields_10078153074973_hint').html("This is the unique identifier of the account that the transaction belongs to that links to the PAN.");
      	var multi_transactions_reporting = $(".form-field.request_custom_fields_16260216639132").append('<p id="request_description_hint">If yes, attach a completed version of the following document: <a class="desc-link" href="/hc/en-us/article_attachments/16260473148828" target="_blank" class="attachment-meta-item meta-data" title="Download">Fraud Reporting_Bulk Template.xlsx</a></p>');
    }
  	
  	/* Transaction Dispute BETA */
  	else if (queryString == "?ticket_form_id=20029681614364") {				
        var desc_label = $('label[for="request_description"]').html("Additional Info");
        var desc_hint = $('#request_description_hint').html("Provide as much detail as possible");
      	var transaction_status_1_label = $('#request_custom_fields_20029753223580_label').html("Transaction Status [#1]");
      	var transaction_status_1_hint = $('#request_custom_fields_20029753223580_hint').html("This field will be auto-populated if your transaction is found | <strong>SETTLED</strong> means the Transaction can be disputed | <strong>PENDING</strong> means the transaction cannot be disputed and should be re-checked in 10 days");
    }
  
  /* FlexPay ATM Claim */
  else if (queryString == "?ticket_form_id=22474020081052") {	
    		var org_name = HelpCenter.user.organizations[0].name;
        var today = getDate();
    		
        var desc_label = $('label[for="request_description"]').html("Any other information");
        var set_subject = $('#request_subject').val('FlexPay ATM Claim  - ' + String(today) + ' [' + org_name + ']');
    }
  
  /* FlexPay Fraud Claim */
  else if (queryString == "?ticket_form_id=22474332817052") {	
    		var org_name = HelpCenter.user.organizations[0].name;
        var today = getDate();
    		
        var desc_label = $('label[for="request_description"]').html("Any other information");
        var set_subject = $('#request_subject').val('FlexPay Fraud Claim  - ' + String(today) + ' [' + org_name + ']');
    }
}

const getDate = () => {
  const newDate = new Date();
  const year = newDate.getFullYear();
  const month = newDate.getMonth() + 1;
  const d = newDate.getDate();
  
  return `${d.toString().padStart(2, '0')}-${month.toString().padStart(2, '0')}-${year}`;
}

// Displays a hint under the Severity Field
function displayRichHints() {
	/*$(".form-field.request_custom_fields_8602132237853").append('<p id="request_description_hint">[P1] - Production service is completely unavailable (reserved for Production environment incidents) | [P2] - System is partially unavailable | [P3] - An issue is causing difficulty for your customers | [P4] - An issue is causing minor problems for your customers | More information on how we prioritise your Service Incident is available <a href="https://paymentology1670598589.zendesk.com/hc/en-us/articles/8602700730781-How-Paymentology-prioritise-your-Service-Incidents">here</a></p>');*/

	$(".form-field.request_custom_fields_9251007583517").append('<p id="request_description_hint"><b>[P1]</b> - 100% of all Authorisation Requests Calls are failing (reserved for Production environment incidents) | <b>[P2]</b> - >25% but <100% of Authorisation Requests Calls are failing | <b>[P3]</b> - <25% of Authorisation Requests Calls are failing and more than 50 cards affected | <b>[P4]</b> - Isolated Processing Failure affecting less than 50 cards for >1 hour | More information on how we prioritise your Service Incident is available <a href="https://support.paymentology.com/hc/en-us/articles/9234678812573" target="_blank" rel="noopener noreferrer">here</a></p>');
	
	$(".form-field.request_custom_fields_9251019535389").append('<p id="request_description_hint"><b>[P1]</b> - Online service not available to cardholder / No transaction are pocessing (reserved for Production environment incidents) | <b>[P2]</b> - Online service not available to some cardholders / Most transactions are not processing | <b>[P3]</b> - Intermittent failures to online service / High transaction failure rate | <b>[P4]</b> - Issue related to service, that does not effect transaction processing (Ex. reports not received) | More information on how we prioritise your Service Incident is available <a href="https://support.paymentology.com/hc/en-us/articles/9234678812573" target="_blank" rel="noopener noreferrer">here</a></p>');
  
  // Transaction Disputes - Num of Transactions
	if (window.location.href.includes("/requests/new?ticket_form_id=10126232762781")) {
    $(".form-field.request_custom_fields_10078038933405").append('<p id="request_description_hint">Number of transactions associated with this request | If you are submitting more than <b>5 disptues</b>, complete and attach the following document: <a class="desc-link" href="/hc/en-us/article_attachments/13302295181724" target="_blank" class="attachment-meta-item meta-data" title="Download">Transaction-list.xlsx</a></p>');
  
  $(".form-field.request_custom_fields_10078077141277").append('<p id="request_description_hint">Number of transactions associated with this request | If you are submitting more than <b>5 disptues</b>, complete and attach the following document: <a class="desc-link" href="/hc/en-us/article_attachments/13302295181724" target="_blank" class="attachment-meta-item meta-data" title="Download">Transaction-list.xlsx</a></p>');
  }
  
  // Transaction Disputes BETA - Num of Transactions
	if (window.location.href.includes("/requests/new?ticket_form_id=20029681614364")) {
    $(".form-field.request_custom_fields_10078038933405").append('<p id="request_description_hint">Up to <strong>5 transactions</strong> can be populated on this form | If you are submitting more than <b>5 disptues</b>, complete and attach the following document: <a class="desc-link" href="/hc/en-us/article_attachments/13302295181724" target="_blank" class="attachment-meta-item meta-data" title="Download">Transaction-list.xlsx</a></p>');
  
    $(".form-field.request_custom_fields_10078077141277").append('<p id="request_description_hint">Up to <strong>5 transactions</strong> can be populated on this form | If you are submitting more than <b>5 disptues</b>, complete and attach the following document: <a class="desc-link" href="/hc/en-us/article_attachments/13302295181724" target="_blank" class="attachment-meta-item meta-data" title="Download">Transaction-list.xlsx</a></p>');
  }
}

// Removes platform options from the Customer-set Platform field based on their Organisation Tags 
function removePlatformOptions(tags) {
  $('.nesty-panel').on('DOMNodeInserted', function(e) {  
    if (!tags.includes("platform_banking_live")) {
    	$('li#platform-field_banking-live_clone').remove();
    }
    
    if (!tags.includes("platform_voucherengine")) {
    	$('li#platform-field_voucherengine_clone').remove();
    }
    
    if (!tags.includes("platform_flexpay")) {
    	$('li#platform-field_flexpay_clone').remove();
    }
    
    if (!tags.includes("platform_acorn")) {
    	$('li#platform-field_acorn_clone').remove();
    }
	});
}

// Sets the platform option from the Customer-set Platform field based on their Organisation Tags, if they only have one field
function setPlatformOptions(tags) {      
  if (tags.includes("platform_banking_live")) {
  	$('#request_custom_fields_9251074605597').val("platform-field_banking-live_clone").change();
  }
    
  if (tags.includes("platform_acorn")) {
  	$('#request_custom_fields_9251074605597').val("platform-field_acorn_clone").change();
  }    
    
  if (tags.includes("platform_voucherengine")) {
  	$('#request_custom_fields_9251074605597').val("platform-field_voucherengine_clone").change();
  }
    
  if (tags.includes("platform_flexpay")) {
  	$('#request_custom_fields_9251074605597').val("platform-field_flexpay_clone").change();
  }
}

// Sets the Disputes fields depending on the customers default Disputes setup based on their Organisation Tags, if they only have one Organisation
function setDisputesFields(tags) {      
  // Set the Default MX Domestic Dispute value
  if (tags.includes("dispute_default_mx_no")) {
  	$('#request_custom_fields_10077852170269').val("mx-dispute_no").change();
  }
    
  if (tags.includes("dispute_default_mx_yes")) {
  	$('#request_custom_fields_10077852170269').val("mx-dispute_yes").change();
  }    
  
  // Set the Card Brand value
  if (tags.includes("dispute_default_brand_cup")) {
  	$('#request_custom_fields_10077867699229').val("card-type_cup").change();
  }
    
  if (tags.includes("dispute_default_brand_mc")) {
  	$('#request_custom_fields_10077867699229').val("card-type_mc").change();
  }   
  
  if (tags.includes("dispute_default_brand_visa")) {
  	$('#request_custom_fields_10077867699229').val("card-type_vs").change();
  }   
  
  // Set the Default Transaction Processor value
  if (tags.includes("dispute_default_bancnet")) {
  	$('#request_custom_fields_10077930929821').val("processor_bancnet").change();
  }
    
  if (tags.includes("dispute_default_cup")) {
  	$('#request_custom_fields_10077930929821').val("processor_cup").change();
  }
  
  if (tags.includes("dispute_default_mc")) {
  	$('#request_custom_fields_10077930929821').val("processor_mc").change();
  }
  
  if (tags.includes("dispute_default_visa")) {
  	$('#request_custom_fields_10077930929821').val("processor_vs").change();
  }
  
  // Set the Card Number Type value
  if (tags.includes("dispute_default_tracking_num")) {
  	$('#request_custom_fields_10078129985949').val("card-num_tracking-num").change();
  }
  
  if (tags.includes("dispute_default_wallet_id")) {
  	$('#request_custom_fields_10078129985949').val("card-num_wallet-id").change();
  }
}

// Remove the Urgency options that are not relevant to customers
function removeUrgencyTag() {
	$('.nesty-panel').on('DOMNodeInserted', function(e) {
		for (var i in urgency_tag_list) {
			$('li#' + urgency_tag_list[i]).remove();
		}
	});
}


/* FORM RESTRICTIONS */
/* Remove Ticket Form based on Organisation */
  $(window).on('load', function() {
    var i = 0;
    var checkExist = setInterval(function() {
        i++;

      	if ($("a.nesty-input").length) {
            clearInterval(checkExist);
						
          	// console.log(HelpCenter.user.organizations)
						
            $("a.nesty-input").each(function() {
                $(this).bind("click", function() {
                  	/* Check if the user has any organisations */
                  	// console.log(HelpCenter.user.organizations.length)
                  	// Remove legacy Dispute Form for all users
                  	$("#10126232762781").remove();
                  
                  	if (HelpCenter.user.organizations.length > 0) {
                      	/* Iterate through all organisations associated with the user to find if they have the required tags to view forms */ 
                        for (var c in HelpCenter.user.organizations) {
                          var org_name = HelpCenter.user.organizations[c].name
                          var org_tags = HelpCenter.user.organizations[c].tags
                          var user_tags = HelpCenter.user.tags
                          // console.log(user_tags)
                          
                          // Check to see if the customer can see the Fraud Rule forms (Banking.Live only)
                          if (!org_tags.includes("platform_banking_live") && org_name != "Paymentology") {
                              $("#11811109144989").remove(); // Fraud form - amend / delete rule
                            	$("#11811207026589").remove(); // Fraud form - new rule 
                          }
                          
                          // Dispute Form
                          // Keep temporary org exceptions until organisation tagging is fully in place.
                          var canAccessDisputeForm =
                            org_tags.includes("cb_processing-yes") ||
                            org_tags.includes("product_sprint") ||
                            org_name == "Paymentology" ||
                            org_name == "Mama Money";

                          if (!canAccessDisputeForm || org_name == "Agoda") {
                          		$("#10126232762781").remove(); // Chargeback form
                            	$("#20029681614364").remove(); // Beta Dispute form
                          }
                          
                          // Pilot
                          if (!org_tags.includes("org_pilot_project_ongoing_yes")) {
                          		$("#12313589819292").remove(); // Pilot form
                          }
                          
                          if (!(org_name == "Agoda" || org_name == "Paymentology")) {
                            	$("#11833023866268").remove(); // Chargeback Form [custom]
                          }
                          
                          // MC Fraud Reporting
                          if (!(org_name == "Ascend Group (True Money)" || org_name == "Albo" || org_name == "Paymentology")) {
                            	$("#16257750048796").remove();
                          }
                          
                          // Acorn Forms
                          if (!org_tags.includes("platform_acorn") && org_name != "Paymentology") {
                            	$("#13775208908444").remove(); // FICA Product Transfer
                            	$("#13778338328732").remove(); // Excess Fund Transfer
                            	$("#15215270503196").remove(); // FlexPay ATM Claim
                            	$("#22474332817052").remove(); // FlexPay Fraud Claim
                          }
                          
                          if (!org_tags.includes("platform_banking_live") && org_name != "Paymentology") {
                            	$("#15215216284572").remove(); // Token > PAN Conversion
                          }
                          
                          if (org_name != "Paymentology") {
                            	$("#28452861569180").remove(); // Campaign Change Request
                          }
                          
                          
                          /* if (!user_tags.includes("org_role-authorised_user")) {
                            	// console.log("Removing CR")
                            	$("#16269775102236").remove(); // CR
                          }*/
                          
                          
                          
                          //reserve space for additional organizations 
                      }
                  }
                  
                  // Not part of any organisation
                  else {
                    $("#10126232762781").remove(); // CB 
                    $("#11833023866268").remove(); // CB Custom
                    $("#11811109144989").remove(); // FR amend / delete
                  	$("#11811207026589").remove(); // FR new
                    $("#12313589819292").remove(); // Pilot
                  	$("#15215216284572").remove(); // Token
                    $("#15215270503196").remove(); // Tracking number
                    $("#16269775102236").remove(); // CR
                    $("#20029681614364").remove(); // Dispute Test
                    $("#20029681614364").remove(); // Flexpay ATM Claim
                    $("#22474332817052").remove(); // FlexPay Fraud Claim
                  }
                });
            });
        }

        if (i > 10) {
            clearInterval(checkExist);
        }
    }, 100);
});


function addFancyBox() {
  var images = document.querySelectorAll('.article-body img');
  images.forEach(function(el) {
    el.setAttribute('data-fancybox','');
  })
}

function showToast(content = "Unknown error") {
  // Get the snackbar DIV
  var x = document.getElementById("snackbar");
  
  //Change the text (not mandatory, but I think you might be willing to do it)
  x.innerHTML = content;

  // Add the "show" class to DIV
  x.className = "show";

  // After 3 seconds, remove the show class from DIV
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
};

async function getUser() {
	try {
      const response = await fetch("/api/v2/users/me.json")
      
      res_json = response.json()
    
    	return res_json
  }
  catch (error) {
    console.error(error)
  }
};

/* TEMPORARY SETTING */
/*$(window).on('load', function() {
    var i = 0;
    var checkExist = setInterval(function() {
        i++;
        if ($("a.nesty-input").length) {
            clearInterval(checkExist);
            $("a.nesty-input").each(function() {
                $(this).bind("click", function() {
                    for (var c in HelpCenter.user.organizations) {
                        if (HelpCenter.user.organizations[c].name !== "Paymentology") {
                          	console.log('Removing Form options')
                            $("#9252743303837").remove(); // Access Request
                          	$("#9252769581341").remove(); // Card Request
 		                        $("#9252814736029").remove(); // Product Query
                          	$("#9252182331037").remove(); // Service Incident
                        }
                        //reserve space for additional organizations 
                    }

                });
            });
        }
        if (i > 10) {
            clearInterval(checkExist);
        }
    }, 100);
});*/

/* ALERT BANNER */
// MW-Notification Banner
window.addEventListener("load", displayBanner);


async function displayBanner() {
  const labels = ["alert-incident", "alert-warning"];
  let container = document.querySelector(".alert-banner-host");

  if (!container) {
    const layout = document.querySelector(".layout");
    if (!layout) return;

    layout.insertAdjacentHTML(
      "beforebegin",
      '<div class="alert-banner-host"></div>'
    );

    container = layout.previousElementSibling;
  }

  const locale = document
    .querySelector("html")
    .getAttribute("lang")
    .toLowerCase();

  for (const label of labels) {
    const apiUrl = `/api/v2/help_center/${locale}/articles.json?label_names=${label}`;
    const data = await (await fetch(apiUrl)).json();
    const articles = (data && data.articles) || [];

    for (let i = 0; i < articles.length; i++) {
      
      switch (label) {
          
        /*INCIDENT NOTIFICATION*/
        case "alert-incident": {
          container.insertAdjacentHTML(
            "beforeend",
            '<div data-element="notification" data-type="error" data-labels="alert-incident"></div>'
          );

          const node = container.lastElementChild;
          new Notification(node, {
            type: "error",
            labels: "alert-incident",
            template: "linked-alert-notification",
            dismissible: true,
          });
          break;
        }
          
				/*WARNING NOTIFICATION*/
        case "alert-warning": {
          container.insertAdjacentHTML(
            "beforeend",
            '<div data-element="notification" data-type="warning" data-labels="alert-warning"></div>'
          );

          const node = container.lastElementChild;
          new Notification(node, {
            type: "warning",
            labels: "alert-warning",
            template: "linked-alert-notification",
            dismissible: true,
          });
          break;
        }
      }
    }
  }
}
