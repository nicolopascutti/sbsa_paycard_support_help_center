(function () {
  "use strict";

  function getCurrentRequestId() {
    var requestClass = Array.prototype.find.call(
      document.documentElement.classList,
      function (className) {
        return /^request-\d+$/.test(className);
      }
    );

    return requestClass ? requestClass.replace("request-", "") : null;
  }

  function buildLocalizedNewRequestPath() {
    var match = window.location.pathname.match(/^\/hc\/[^/]+/);
    var basePath = match ? match[0] : "/hc/en-us";
    return basePath + "/requests/new";
  }

  function rewriteFollowUpLink() {
    var callout = document.getElementById("request-comment-callout");
    if (!callout) {
      return;
    }

    var followUpLink = callout.querySelector('a[href*="parent_id="]');
    if (!followUpLink) {
      return;
    }

    var requestId = getCurrentRequestId();
    if (!requestId) {
      return;
    }

    var originalUrl;
    try {
      originalUrl = new URL(followUpLink.href, window.location.origin);
    } catch (error) {
      return;
    }

    var parentId = originalUrl.searchParams.get("parent_id");
    if (!parentId) {
      return;
    }

    fetch("/api/v2/requests/" + encodeURIComponent(requestId) + ".json", {
      credentials: "same-origin",
      headers: {
        Accept: "application/json",
      },
    })
      .then(function (response) {
        if (!response.ok) {
          throw new Error("Failed to load request details");
        }
        return response.json();
      })
      .then(function (payload) {
        var request = payload && payload.request;
        var ticketFormId = request && request.ticket_form_id;
        if (!ticketFormId) {
          return;
        }

        var redirectUrl = new URL(
          buildLocalizedNewRequestPath(),
          window.location.origin
        );
        redirectUrl.searchParams.set("ticket_form_id", ticketFormId);
        redirectUrl.searchParams.set("parent_id", parentId);

        followUpLink.href = redirectUrl.toString();
      })
      .catch(function () {
        // Keep Zendesk's default follow-up link when the form ID is unavailable.
      });
  }

  // Submit organization form when a new organization is selected
  var requestOrganisationSelect = document.querySelector(
    "#request-organization select"
  );
  if (requestOrganisationSelect) {
    requestOrganisationSelect.addEventListener("change", function () {
      Util.closest(this, "form").submit();
    });
  }

  rewriteFollowUpLink();

  // Do nothing if the form or comment textarea does not exist on the page
  var form = document.querySelector('form[data-form-type="comment"]');
  if (!form) {
    return;
  }

  /**
   * Solves the request.
   */
  function solveRequest() {
    solvedCheckbox.checked = true;
    form.submit();
  }

  // Maybe allow end-users to mark the request as solved
  var solvedButton = form.querySelector("button");
  var solvedCheckbox = form.querySelector('input[type="checkbox"]');
  if (solvedButton && solvedCheckbox) {
    solvedButton.addEventListener("click", solveRequest);
  }
})();
