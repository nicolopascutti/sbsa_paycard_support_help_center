DEBUG_REQUIRE = false;
async function N8N_GetCsvFile(organizationId, organizationName) {

    const { token } = await fetch('/api/v2/help_center/integration/token.json', { credentials: 'include' })
        .then(r => r.json());
    const r = await fetch('https://dbxijaghk4zve.cloudfront.net/webhook/1bf487e8-3293-4507-b52a-86a8a706e438/exportCsv', {
        method: 'POST',
        mode: 'cors',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}` // important
        },
        body: JSON.stringify({ organizationId: organizationId, organizationName: organizationName })
    });
    console.warn('test', r);

    if (!r.ok) {
        console.error('Error getting CSV file:', r.status, await r.text());
        return null;
    }

    const data = await r.json();
    if (DEBUG_REQUIRE) console.log('output:', data.csvBase64);
    return data.csvBase64;
}



document.addEventListener('DOMContentLoaded', function() {
  var btn = document.getElementById('btn-export-csv');
  
  if (btn) {
    function showModal(orgs) {
      // Backdrop
      var backdrop = document.createElement('div');
      backdrop.className = 'csv-modal-backdrop';
      backdrop.id = 'csv-modal-backdrop';
      
      // Modal
      var modal = document.createElement('div');
      modal.className = 'csv-modal';
      modal.id = 'csv-modal';
      
      var orgOptions = orgs.map(function(org, index) {
        return '<label><input type="radio" name="csv-org" value="' + index + '"' + (index === 0 ? ' checked' : '') + '> ' + org.name + '</label>';
      }).join('');
      
      modal.innerHTML = `
        <div class="csv-modal-header">
          <p>Export Tickets CSV</p>
          <button class="csv-modal-close" id="csv-modal-close">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" focusable="false" viewBox="0 0 16 16" aria-hidden="true">
              <path stroke="currentColor" stroke-linecap="round" d="M3 13L13 3m0 10L3 3"></path>
            </svg>
          </button>
        </div>
        <div class="csv-modal-body">
          <p>Select an organization to export:</p>
          ${orgOptions}
        </div>
        <div class="csv-modal-footer">
          <button class="csv-modal-btn csv-modal-btn-export" id="csv-modal-export">Export</button>
        </div>
      `;
      
      document.body.appendChild(backdrop);
      document.body.appendChild(modal);
      
      // Close handlers
      document.getElementById('csv-modal-close').addEventListener('click', closeModal);
      backdrop.addEventListener('click', closeModal);
      
      // Export handler
      document.getElementById('csv-modal-export').addEventListener('click', async function() {
        var selected = document.querySelector('input[name="csv-org"]:checked');
        if (selected) {
          var org = orgs[parseInt(selected.value)];
          closeModal();
          await doExport(org);
        }
      });
    }
    
    function closeModal() {
      var modal = document.getElementById('csv-modal');
      var backdrop = document.getElementById('csv-modal-backdrop');
      if (modal) modal.remove();
      if (backdrop) backdrop.remove();
    }
    
    async function exportCsv(org) {
      console.log('Exporting CSV for:', org.name, '(ID:', org.id, ')');
      var base64Data = await N8N_GetCsvFile(org.id, org.name);
      if (!base64Data) {
        throw new Error('Failed to export CSV');
      }
      console.log('CSV export complete, downloading...');
      
      // Decode base64 and download
      downloadCsvFromBase64(base64Data, org.name + '_tickets.csv');
    }
    
    function downloadCsvFromBase64(base64Data, filename) {
      // Decode base64 to binary
      var binaryString = atob(base64Data);
      var bytes = new Uint8Array(binaryString.length);
      for (var i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      // Create blob and download
      var blob = new Blob([bytes], { type: 'text/csv;charset=utf-8;' });
      var url = URL.createObjectURL(blob);
      
      var link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Cleanup
      URL.revokeObjectURL(url);
    }
    
    // Create or get error element
    function getOrCreateError() {
      var errorEl = document.getElementById('csv-export-error');
      if (!errorEl) {
        // Wrap button in container if not already
        var wrapper = btn.parentNode;
        if (!wrapper.classList.contains('csv-export-wrapper')) {
          wrapper = document.createElement('div');
          wrapper.className = 'csv-export-wrapper';
          btn.parentNode.insertBefore(wrapper, btn);
          wrapper.appendChild(btn);
        }
        
        errorEl = document.createElement('div');
        errorEl.id = 'csv-export-error';
        errorEl.className = 'csv-export-error';
        wrapper.appendChild(errorEl);
      }
      return errorEl;
    }
    
    // Do export with loading state on main button
    async function doExport(org) {
      var errorEl = getOrCreateError();
      
      // Set loading state on main button
      btn.classList.add('csv-btn-loading');
      btn.disabled = true;
      errorEl.textContent = '';
      errorEl.style.display = 'none';
      
      try {
        await exportCsv(org);
      } catch (error) {
        console.error('Export error:', error);
        errorEl.textContent = 'An unexpected error happened, try again';
        errorEl.style.display = 'inline';
      } finally {
        btn.classList.remove('csv-btn-loading');
        btn.disabled = false;
      }
    }
    
    btn.addEventListener('click', async function() {
      var orgs = window.userOrganizations || [];
      
      if (orgs.length === 0) {
        alert('No organizations found.');
        return;
      }
      
      if (orgs.length === 1) {
        // Direct export
        await doExport(orgs[0]);
      } else {
        // Show modal
        showModal(orgs);
      }
    });
  }
});




